/*
 * Copyright (c) Jam.gg 2024.
 * Copyright (c) Filippo Scognamiglio 2025.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package gg.padkit.anchors

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import gg.padkit.utils.Constants
import gg.padkit.utils.GeometryUtils
import gg.padkit.utils.GeometryUtils.toRadians
import kotlinx.collections.immutable.PersistentList
import kotlinx.collections.immutable.persistentListOf
import kotlinx.collections.immutable.persistentSetOf
import kotlinx.collections.immutable.toPersistentList
import kotlin.math.cos
import kotlin.math.sin

@Composable
internal fun <T> rememberPrimaryAnchors(
    ids: PersistentList<T>,
    rotationInDegrees: Float,
): PersistentList<Anchor<T>> {
    return remember(ids, rotationInDegrees) {
        if (ids.size == 1) {
            return@remember persistentListOf(
                Anchor(Offset.Zero, persistentSetOf(ids.first()), 0.5f),
            )
        }
        val baseRotation = rotationInDegrees.toRadians()
        val size = GeometryUtils.computeSizeOfItemsOnCircumference(ids.size)

        val primaryAnchors =
            ids.mapIndexed { index, id ->
                val angle = (baseRotation + Constants.PI2 * index / ids.size)
                Anchor(
                    Offset(cos(angle), sin(angle)),
                    persistentSetOf(id),
                    size,
                )
            }

        primaryAnchors.toPersistentList()
    }
}
