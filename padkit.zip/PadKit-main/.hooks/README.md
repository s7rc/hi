# Install Git Hooks
`./gradlew setUpGitHooks`
