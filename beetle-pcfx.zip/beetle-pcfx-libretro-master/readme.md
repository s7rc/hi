[![Build Status](https://travis-ci.org/libretro/beetle-pcfx-libretro.svg?branch=master)](https://travis-ci.org/libretro/beetle-pcfx-libretro)
[![Build status](https://ci.appveyor.com/api/projects/status/s9d2tymlinoe0ijn/branch/master?svg=true)](https://ci.appveyor.com/project/bparker06/beetle-pcfx-libretro/branch/master)

# Beetle PC-FX
