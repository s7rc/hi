#ifndef __CHDCONFIG_H__
#define __CHDCONFIG_H__

/* Configure CHDR features here */
#define WANT_RAW_DATA_SECTOR    1
#define WANT_SUBCODE            1
#define NEED_CACHE_HUNK         1
#define VERIFY_BLOCK_CRC        1

#endif
